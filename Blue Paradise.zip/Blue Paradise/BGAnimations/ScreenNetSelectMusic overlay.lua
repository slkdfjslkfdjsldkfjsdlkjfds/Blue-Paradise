local t = LoadActor("ScreenSelectMusic overlay/default")
t[#t+1] = LoadActor("_userlist")
return t 