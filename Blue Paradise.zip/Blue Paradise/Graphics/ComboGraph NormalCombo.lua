return Def.Quad {
	InitCommand = function(self)
		self:setsize(1, 12):diffuse(getMainColor("highlight")):diffusealpha(0.7)
	end
}
