return Def.Quad {
	InitCommand = function(self)
		self:FullScreen():Center():diffuse(color("#000000"))
	end
}
