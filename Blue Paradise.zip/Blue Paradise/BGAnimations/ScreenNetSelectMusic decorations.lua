local t = LoadActor("ScreenSelectMusic decorations/default")
return t