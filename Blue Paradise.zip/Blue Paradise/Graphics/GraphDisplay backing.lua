return Def.Quad {
	InitCommand = function(self)
		self:setsize(256, 80):diffuse(color("#999999")):diffusealpha(0.7):diffusebottomedge(color("#00000033"))
	end
}
