local t = Def.ActorFrame {}
t[#t + 1] = LoadActor("_cursor")
return t
