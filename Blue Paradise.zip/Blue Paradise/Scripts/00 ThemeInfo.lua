-- theme identification file

themeInfo = {
	Name = "Blue Paradise",
	Version = "1.11",
	Date = "20250122"
}

function getThemeName()
	return themeInfo["Name"]
end

function getThemeVersion()
	return themeInfo["Version"]
end

function getThemeDate()
	return themeInfo["Date"]
end
